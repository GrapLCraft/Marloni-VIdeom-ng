import pygame, sys, time, os
from pygame.locals import *

pygame.init()

#Mängu windowi suurus
screen_width = 816
screen_height = 624

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('vangikoopa põgenemine')

tile_size = 48

moving_left = False
moving_right = False
sliding = False
#running = False
shoot = False



#vajalikud funktsioonid
clock = pygame.time.Clock()

FPS = 60
GRAVITY = 0.75

pygame.mixer.music.load("music/music1.mp3")
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.5)

#sun_img = pygame.image.load('img/päike.png')
#bg_img = pygame.image.load('img/dungeon3.png')
#bg_img = pygame.transform.scale(bg_img, (816, 624))


#portal_blue_img = pygame.image.load("img/portal_blue.png")
#portal_blue_img = pygame.transform.scale(portal_blue_img, (64, 96))
#portal_blue_rect = portal_blue_img.get_rect(topleft = (480, 192))

#portal_purple_img = pygame.image.load("img/portal_purple.png")
#portal_purple_img = pygame.transform.scale(portal_purple_img, (64, 96))
#portal_purple_rect = portal_purple_img.get_rect(topleft = (368, 192))

def draw_grid():
    for line in range(0, 17):
        pygame.draw.line(screen, (255, 255, 255), (0, line * tile_size), (screen_width, line * tile_size))
        pygame.draw.line(screen, (255, 255, 255), (line * tile_size, 0), (line * tile_size, screen_height))


class World1():
    def __init__(self, data):
        self.tile_list = []
        
        #Laeb pildid
        brick_img = pygame.image.load("img/brick.png")
        brick_img = pygame.transform.scale(brick_img, (48, 48))
        brick1_img = pygame.image.load("img/brick_top.png")
        brick1_img = pygame.transform.scale(brick1_img, (48, 48))
        floor_img = pygame.image.load("img/floor.png")
        floor_img = pygame.transform.scale(floor_img, (48, 48))

        
        brick_top_lava_img = pygame.image.load("img/brick_top_lava.png")
        brick_top_lava_img = pygame.transform.scale(brick_top_lava_img, (48, 48))

        

        
        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = brick_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = floor_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    img = portal_blue_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 4:
                    img = lava_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 5:
                    img = brick_top_lava_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                col_count += 1
            row_count += 1
        
        
            
    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])
            #pygame.draw.rect(screen, (0, 0, 0), tile[1], 1)
            

#load in level data
#pickle_in = open("level_1", "rb")
#world_data = pickle.load(pickle_in)
world1_data = [
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 2, 2, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 2, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 0, 1, 1],
[1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 5, 5, 1, 1],
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

world = World1(world1_data)

#---------------------------------------------------------------------
class World2():
    def __init__(self, data):
        self.tile_list = []
        
        #Laeb pildid
        brick2_img = pygame.image.load("img/brick1.png")
        brick2_img = pygame.transform.scale(brick2_img, (48, 48))
        grass_img = pygame.image.load("img/grass_img.png")
        grass_img = pygame.transform.scale(grass_img, (48, 48))
        dirt_img = pygame.image.load("img/dirt.png")
        dirt_img = pygame.transform.scale(dirt_img, (48, 48))
        bg_img = pygame.image.load("img/sky.png")
        car_img = pygame.image.load("img/car.png")
        car_img = pygame.transform.scale(car_img, (128, 96))
        planks_img = pygame.image.load("img/planks.png")
        planks_img = pygame.transform.scale(planks_img, (48, 48))
        wood_img = pygame.image.load("img/wood.png")
        wood_img = pygame.transform.scale(wood_img, (48, 48))
        door_img = pygame.image.load("img/door.png")
        door_img = pygame.transform.scale(door_img, (48, 96))
        roof_img = pygame.image.load("img/roof.png")
        roof_img = pygame.transform.scale(roof_img, (48, 48))
        roof_flip_img = pygame.image.load("img/roof_flip.png")
        roof_flip_img = pygame.transform.scale(roof_flip_img, (48, 48))
        heaven_img = pygame.image.load("img/heaven.png")
        heaven_img = pygame.transform.scale(heaven_img, (48, 9))


        
        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = brick2_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = dirt_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    img = grass_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 4:
                    img = car_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 5:
                    img = wood_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 6:
                    img = planks_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 7:
                    img = door_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 8:
                    img = wood_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 9:
                    img = roof_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 10:
                    img = roof_flip_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 11:
                    img = heaven_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                col_count += 1
            row_count += 1
        
        
            
    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])
            #pygame.draw.rect(screen, (0, 0, 0), tile[1], 1)
            
    

world2_data = [
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 11, 11, 11, 11, 11, 11, 11, 1],
[1, 0, 0, 0, 0, 10, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 10, 10, 9, 9, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 10, 10, 10, 9, 9, 9, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 5, 6, 6, 6, 6, 5, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 5, 6, 7, 6, 6, 5, 4, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 5, 6, 0, 6, 6, 5, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 1],
[1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 1],
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

world2 = World2(world2_data)

#----------------------------------------------------------------------

class World3():
    def __init__(self, data):
        self.tile_list = []
        
        #Laeb pildid
        pipe_img = pygame.image.load("img/pipe.png")
        pipe_img = pygame.transform.scale(pipe_img, (48, 48))
        pipe_top_img = pygame.image.load("img/pipe_top.png")
        pipe_top_img = pygame.transform.scale(pipe_top_img, (48, 48))
        platform_img = pygame.image.load("img/platform.png")
        platform_img = pygame.transform.scale(platform_img, (144, 48))
        cloud_img = pygame.image.load("img/clouds.png")
        cloud_img = pygame.transform.scale(cloud_img, (48, 48))

        
        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = cloud_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = pipe_top_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    img = platform_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 4:
                    img = pipe_img
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)

                col_count += 1
            row_count += 1
        
        
            
    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])
            #pygame.draw.rect(screen, (0, 0, 0), tile[1], 1)
            

#load in level data
#pickle_in = open("level_1", "rb")
#world_data = pickle.load(pickle_in)
world3_data = [
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 4, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 4, 0, 1],
[1, 3, 0, 0, 3, 0, 0, 0, 0, 0, 4, 0, 0, 0, 4, 0, 1],
[1, 0, 2, 0, 0, 2, 0, 0, 0, 0, 4, 0, 0, 0, 4, 0, 1],
[1, 0, 4, 0, 0, 4, 0, 0, 0, 0, 4, 0, 0, 0, 4, 0, 1],
[1, 0, 4, 0, 0, 4, 0, 0, 0, 0, 4, 0, 0, 0, 4, 0, 1],
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

world3 = World3(world3_data)



#----------------------------------------------------------------------
        
class Entity(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, jump_height, speed):
        pygame.sprite.Sprite.__init__(self)
        self.sliding1 = 0
        self.alive = True
        self.char_type = char_type
        self.speed1 = speed
        self.speed = speed
        self.jump_height = jump_height
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.slide = False
        self.in_air = False
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()
        
        
        #load all images for the players
        animation_types = ['idle', 'run', 'jump', 'slide', 'shoot']
        for animation in animation_types:
            #reset temporary list of images
            temp_list = []
            #count number of files in the folder
            num_of_frames = len(os.listdir(f'img/{self.char_type}/{animation}'))
            for i in range(num_of_frames):
                img = pygame.image.load(f'img/{self.char_type}/{animation}/{i}.png')
                img = pygame.transform.scale(img, (int(img.get_width() * 4), int(img.get_height() * 4)))
                temp_list.append(img)
            self.animation_list.append(temp_list)


        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect(center = (x, y))
    
    def move(self, moving_left, moving_right):
        #reset movement variables
        dx = 0
        dy = 0
        self.dx = dx
        self.dy = dy
        
        #assign movement variables
        if moving_left == True:
            dx = - self.speed
            self.flip = True
            self.direction = -1
        if moving_right == True:
            dx = + self.speed
            self.flip = False
            self.direction = 1
        #jump
        if self.jump == True and self.in_air == True:
            self.vel_y = -self.jump_height
            self.jump = False
            self.in_air = False
        #sliding
        if sliding == True:
            self.speed = 100
            dx = - self.speed
            self.flip = True
            self.direction = -1
        if sliding == True:
            self.speed = 100
            dx = + self.speed
            self.flip = False
            self.direction = 1
        else:
            self.speed = self.speed1
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y
        dy += self.vel_y
        
        #check collision with floor
        #if self.rect.bottom + dy > 624:
            #dy = 624 - self.rect.bottom
            #self.in_air = True
        
        #check for collision
        
        for tile in world.tile_list:
            #check for collision in x direction
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, 64, 64):
                dx = 0
            #check for collision in y direction
            if tile[1].colliderect(player.rect.x, self.rect.y + dy, 64, 64):
                #check if below the ground i.e. jumping
                if self.vel_y < 0:
                    dy = tile[1].bottom - self.rect.top
                    self.vel_y = 0
                #check if above the ground i.e. falling
                elif self.vel_y >= 0:
                    dy = tile[1].top - self.rect.bottom
                    self.vel_y = 0      


        
        
        
        
        
        
        
        #update rectangle pos
        self.rect.x += dx
        self.rect.y += dy
            
    def update_animation(self):
        #update animation
        ANIMATION_COOLDOWN = 100
        #update image depending on current frame
        self.image = self.animation_list[self.action][self.frame_index]
        #check if enough time has passed since last update
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        #if the animation has run out reset back to the start
        if self.frame_index >= len(self.animation_list[self.action]):
            self.frame_index = 0
            
    def update_action(self, new_action):
        #check if the new action is different to the last one
        if new_action != self.action:
            self.action =  new_action
            #update the animation settings
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()
            
        
        
        
    
    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)
        #pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)

    
#--------------------------------------------------       
player = Entity("player", 80, 496, 12.5, 4)        
        
        
        
#Mängu tsükkel
def start():
    running = True
    quit_img = pygame.image.load("img/quit1.png")
    quit_img = pygame.transform.scale(quit_img, (256, 128))
    quit_rect = quit_img.get_rect(center = (600, 312))
    start_img = pygame.image.load("img/start.png")
    start_img = pygame.transform.scale(start_img, (256, 128))
    start_rect = start_img.get_rect(center = (216, 312))
    cursor = pygame.image.load("img/cursor.png")
    cursor = pygame.transform.scale(cursor, (64, 64))
    pygame.mouse.set_visible(False)
    mouse_presses = pygame.mouse.get_pressed()
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit() 
                exit()
            if event.type == MOUSEBUTTONDOWN and cursor_rect.colliderect(start_rect):
                pygame.mouse.set_visible(True)
                player.rect.x = 80
                player.rect.y = 496
                level1()
                running = False
            if event.type == MOUSEBUTTONDOWN and cursor_rect.colliderect(quit_rect):
                pygame.quit()
                exit()
                running = False
            
            
        screen.fill("#160040")
        screen.blit(quit_img, quit_rect)
        screen.blit(start_img, start_rect)
        
        mouse = pygame.mouse.get_pos()
        cursor_rect = cursor.get_rect(center = (mouse))
        
        screen.blit(cursor, cursor_rect)
       
        
        
        
         
        
        
         
        
        pygame.display.update()
        clock.tick(FPS)
        
def level1(): 
    run = True
    moving_left = False 
    moving_right = False
    sliding = False
    #running = False
    shoot = False
    
    bg_img = pygame.image.load('img/dungeon3.png')
    bg_img = pygame.transform.scale(bg_img, (720, 528))

    world1 = World1(world1_data)
    world.tile_list = world1.tile_list

    portal_purple_img = pygame.image.load("img/portal_purple.png")
    portal_purple_img = pygame.transform.scale(portal_purple_img, (64, 96))
    portal_purple_rect = portal_purple_img.get_rect(topleft = (368, 192))
    portal_blue_img = pygame.image.load("img/portal_blue.png")
    portal_blue_img = pygame.transform.scale(portal_blue_img, (64, 96))
    portal_blue_rect = portal_blue_img.get_rect(topleft = (480, 192))
    exit_img = pygame.image.load("img/exit.png")
    exit_img = pygame.transform.scale(exit_img, (48, 96))
    exit_rect = exit_img.get_rect(topleft = (720, 48))
    lava_img = pygame.image.load("img/lava.png")
    lava_img = pygame.transform.scale(lava_img, (96, 48))
    lava_rect = lava_img.get_rect(topleft = (624, 480))
    
    while run:
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
                
                
                #keyboard presses
            #key pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    moving_left = True
                if event.key == pygame.K_d:
                    moving_right = True
                if event.key == pygame.K_w:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = True
                if event.key == pygame.K_LEFT:
                    moving_left = True
                if event.key == pygame.K_RIGHT:
                    moving_right = True
                if event.key == pygame.K_UP:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = True
                if event.key == pygame.K_ESCAPE:
                    start()
                    run = False
            #key released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_w:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = False
                if event.key == pygame.K_LEFT:
                    moving_left = False
                if event.key == pygame.K_RIGHT:
                    moving_right = False
                if event.key == pygame.K_UP:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = False
            
        
                
                
        #draw things
        screen.blit(bg_img, (48, 48))
        screen.blit(lava_img, lava_rect)
        #draw_grid()
        world.draw()
        screen.blit(portal_blue_img, portal_blue_rect)
        screen.blit(portal_purple_img, portal_purple_rect)
        screen.blit(exit_img, exit_rect)
        #print(world.tile_list)
        
        player.update_animation()
        player.draw()
        
        
        
        #update player actions
        if player.alive:

            #walking, sliding, jumping

            if sliding:
                player.update_action(3)#3 means slide
            #elif player.jump and moving_left or player.jump and moving_right:
                #player.update_action(2)#0 means jump
            elif moving_left or moving_right:
                player.update_action(1)#1 means run
            elif player.in_air:
                player.update_action(2)#0 means jump
            else:
                player.update_action(0)#2 means idle
            player.move(moving_left, moving_right)
            if player.rect.colliderect(exit_rect):
                player.rect.x = 576
                player.rect.y = 400
                run = False
                level2()
                
            if player.rect.colliderect(portal_blue_rect):
                player.rect.x -= 240
            if player.rect.colliderect(lava_rect):
                run = False
                start()

        
        

        pygame.display.update()
        clock.tick(FPS)

def level2():
    run1 = True
    moving_left = False
    moving_right = False
    sliding = False
    #running = False
    shoot = False
    
    world.tile_list = world2.tile_list
    bg2_img = pygame.image.load('img/sky.png')
    bg2_img = pygame.transform.scale(bg2_img, (816, 624))
    
    brick_img = pygame.image.load("img/brick.png")
    brick_img = pygame.transform.scale(brick_img, (48, 48))
    brick_top_img = pygame.image.load("img/brick_top.png")
    brick_top_img = pygame.transform.scale(brick_top_img, (48, 48))
        
    exit_img = pygame.image.load("img/exit.png")
    exit_img = pygame.transform.scale(exit_img, (48, 96))
    exit_rect = exit_img.get_rect(topleft = (720, 48))
    while run1:
        #print(player.rect.x, player.rect.y)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        
                
                #keyboard presses
            #key pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    moving_left = True
                if event.key == pygame.K_d:
                    moving_right = True
                if event.key == pygame.K_w:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = True
                if event.key == pygame.K_LEFT:
                    moving_left = True
                if event.key == pygame.K_RIGHT:
                    moving_right = True
                if event.key == pygame.K_UP:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = True
                if event.key == pygame.K_ESCAPE:
                    start()
                    run = False
            #key released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_w:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = False
                if event.key == pygame.K_LEFT:
                    moving_left = False
                if event.key == pygame.K_RIGHT:
                    moving_right = False
                if event.key == pygame.K_UP:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = False
            
        
                
                
        #draw things
        screen.blit(bg2_img, (0, 0))
        screen.blit(brick_top_img, (672, 480))
        screen.blit(brick_img, (672, 528))
        screen.blit(brick_top_img, (720, 480))
        screen.blit(brick_img, (720, 528))
        #draw_grid()
        world2.draw()
        screen.blit(exit_img, exit_rect)
        #print(world.tile_list)
        
        player.update_animation()
        player.draw()
        
        
        
        #update player actions
        if player.alive:

            #walking, sliding, jumping

            if sliding:
                player.update_action(3)#3 means slide
            #elif player.jump and moving_left or player.jump and moving_right:
                #player.update_action(2)#0 means jump
            elif moving_left or moving_right:
                player.update_action(1)#1 means run
            elif player.in_air:
                player.update_action(2)#0 means jump
            else:
                player.update_action(0)#2 means idle
            player.move(moving_left, moving_right)
            
            if player.rect.y == 512:
                run1 = False
                player.rect.x = 80
                player.rect.y = 496
                level1()
                
                
                
            if player.rect.colliderect(exit_rect):
                player.rect.x = 80
                player.rect.y = 312
                level3()

            


        pygame.display.update()
        clock.tick(FPS)



def level3():
    run2 = True
    moving_left = False
    moving_right = False
    sliding = False
    #running = False
    shoot = False
    
    world.tile_list = world3.tile_list
    bg2_img = pygame.image.load('img/sky.png')
    bg2_img = pygame.transform.scale(bg2_img, (816, 624))
    
    brick_img = pygame.image.load("img/brick.png")
    brick_img = pygame.transform.scale(brick_img, (48, 48))
    brick_top_img = pygame.image.load("img/brick_top.png")
    brick_top_img = pygame.transform.scale(brick_top_img, (48, 48))
        
    laps_img = pygame.image.load("img/win1.png")
    laps_img = pygame.transform.scale(laps_img, (96, 96))
    laps_rect = laps_img.get_rect(topleft = (672, 48))
    while run2:
        #print(player.rect.x, player.rect.y)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        
                
                #keyboard presses
            #key pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    moving_left = True
                if event.key == pygame.K_d:
                    moving_right = True
                if event.key == pygame.K_w:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = True
                if event.key == pygame.K_LEFT:
                    moving_left = True
                if event.key == pygame.K_RIGHT:
                    moving_right = True
                if event.key == pygame.K_UP:
                    player.jump = True
                    player.in_air = True
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = True
                if event.key == pygame.K_ESCAPE:
                    start()
                    run = False
            #key released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_w:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_s:
                    sliding = False
                if event.key == pygame.K_SPACE and player.alive:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_LSHIFT and player.alive:
                    sliding = False
                if event.key == pygame.K_LEFT:
                    moving_left = False
                if event.key == pygame.K_RIGHT:
                    moving_right = False
                if event.key == pygame.K_UP:
                    player.jump = False
                    player.in_air = False
                if event.key == pygame.K_DOWN and player.alive:
                    sliding = False
            
        
                
                
        #draw things
        screen.blit(bg2_img, (0, 0))
        screen.blit(laps_img, laps_rect)
        #screen.blit(brick_top_img, (672, 480))
        #screen.blit(brick_img, (672, 528))
        #screen.blit(brick_top_img, (720, 480))
        #screen.blit(brick_img, (720, 528))
        #draw_grid()
        world3.draw()
        #screen.blit(exit_img, exit_rect)
        #print(world.tile_list)
        
        player.update_animation()
        player.draw()
        
        
        
        #update player actions
        if player.alive:

            #walking, sliding, jumping

            if sliding:
                player.update_action(3)#3 means slide
            #elif player.jump and moving_left or player.jump and moving_right:
                #player.update_action(2)#0 means jump
            elif moving_left or moving_right:
                player.update_action(1)#1 means run
            elif player.in_air:
                player.update_action(2)#0 means jump
            else:
                player.update_action(0)#2 means idle
            player.move(moving_left, moving_right)
            
            
            

                
                
                
            if player.rect.colliderect(laps_rect):
                player.rect.x = 80
                player.rect.y = 476
                start()

            


        pygame.display.update()
        clock.tick(FPS)




start()
#level3()
